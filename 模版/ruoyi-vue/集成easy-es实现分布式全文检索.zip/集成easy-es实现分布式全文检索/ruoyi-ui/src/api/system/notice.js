import request from '@/utils/request'

// 查询公告列表
export function listNotice(query) {
  return request({
    url: '/search/fulltext/list',
    method: 'get',
    params: query
  })
}

// 查询公告详细
export function getNotice(noticeId) {
  return request({
    url: '/search/fulltext/' + noticeId,
    method: 'get'
  })
}

// 新增公告
export function addNotice(data) {
  return request({
    url: '/search/fulltext',
    method: 'post',
    data: data
  })
}

// 修改公告
export function updateNotice(data) {
  return request({
    url: '/search/fulltext',
    method: 'put',
    data: data
  })
}

// 删除公告
export function delNotice(noticeId) {
  return request({
    url: '/search/fulltext/' + noticeId,
    method: 'delete'
  })
}

// 刷新索引缓存
export function refreshCache() {
  return request({
    url: '/search/fulltext/resetTextCache',
    method: 'delete'
  })
}