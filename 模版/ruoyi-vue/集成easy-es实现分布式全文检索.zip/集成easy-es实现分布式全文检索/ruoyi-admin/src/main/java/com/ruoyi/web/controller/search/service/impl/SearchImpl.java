package com.ruoyi.web.controller.search.service.impl;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.dromara.easyes.core.biz.EsPageInfo;
import org.dromara.easyes.core.conditions.select.LambdaEsQueryWrapper;
import org.dromara.easyes.core.conditions.update.LambdaEsUpdateWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.bean.BeanUtils;
import com.ruoyi.system.domain.SysNotice;
import com.ruoyi.system.mapper.SysNoticeMapper;
import com.ruoyi.web.controller.search.mapper.EsTextDocumentMapper;
import com.ruoyi.web.controller.search.model.EsTextDocument;
import com.ruoyi.web.controller.search.model.Search;
import com.ruoyi.web.controller.search.service.ISearchService;
import lombok.RequiredArgsConstructor;

/**
 * 实体模板Service业务层处理
 * 
 * @author ruoyi
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SearchImpl implements ISearchService
{
    private final EsTextDocumentMapper esTextDocumentMapper;

    @Autowired
    private SysNoticeMapper noticeMapper;

    /**
     * 项目启动时，初始化索引及数据
     */
    @PostConstruct
    public void init()
    {
        if (!esTextDocumentMapper.existsIndex("text_document"))
        {
            esTextDocumentMapper.createIndex();
        }
    }

    /**
     * 重置全文检索数据
     */
    @Override
    public void resetTextCache()
    {
        esTextDocumentMapper.deleteIndex("text_document");
        esTextDocumentMapper.createIndex();

        List<EsTextDocument> esTextDocumentList = new ArrayList<EsTextDocument>();
        List<SysNotice> noticeList = noticeMapper.selectNoticeList(new SysNotice());
        for (SysNotice sysNotice : noticeList)
        {
            EsTextDocument esTextDocument = new EsTextDocument();
            BeanUtils.copyBeanProp(esTextDocument, sysNotice);
            esTextDocumentList.add(esTextDocument);
        }
        esTextDocumentMapper.insertBatch(esTextDocumentList);
    }

    /**
     * 查询全文检索数据
     */
    @Override
    public EsPageInfo<EsTextDocument> selectTextList(Search search)
    {
        Integer pageNum = search.getPageNum();
        Integer pageSize = search.getPageSize();
        String searchValue = search.getSearchValue();

        LambdaEsQueryWrapper<EsTextDocument> wrapper = new LambdaEsQueryWrapper<>();
        if (StringUtils.isNotEmpty(searchValue))
        {
            wrapper.and(a -> a.match(EsTextDocument::getNoticeTitle, searchValue, 2.0f).or()
                    .match(EsTextDocument::getNoticeContent, searchValue, 1.0f));
        }
        return esTextDocumentMapper.pageQuery(wrapper, pageNum, pageSize);
    }

    /**
     * 新增全文检索数据
     */
    @Override
    public Integer addEsTextDocument(EsTextDocument esTextDocument)
    {
        return esTextDocumentMapper.insert(esTextDocument);
    }

    /**
     * 修改全文检索数据
     */
    @Override
    public Integer updateEsTextDocument(EsTextDocument esTextDocument)
    {

        LambdaEsUpdateWrapper<EsTextDocument> wrapper = new LambdaEsUpdateWrapper<>();
        wrapper.eq(EsTextDocument::getNoticeId, esTextDocument.getNoticeId());
        return esTextDocumentMapper.update(esTextDocument, wrapper);
    }

    /**
     * 根据ID查询全文检索数据
     */
    @Override
    public EsTextDocument getEsTextDocument(Long noticeId)
    {
        LambdaEsQueryWrapper<EsTextDocument> wrapper = new LambdaEsQueryWrapper<EsTextDocument>();
        wrapper.eq(EsTextDocument::getNoticeId, noticeId);
        return esTextDocumentMapper.selectOne(wrapper);
    }

    /**
     * 根据ID删除全文检索数据
     */
    @Override
    public void deleteEsTextDocument(Long[] noticeIds)
    {
        for (Long noticeId : noticeIds)
        {
            LambdaEsQueryWrapper<EsTextDocument> wrapper = new LambdaEsQueryWrapper<EsTextDocument>();
            wrapper.eq(EsTextDocument::getNoticeId, noticeId);
            esTextDocumentMapper.delete(wrapper);
        }
    }
}
