package com.ruoyi.web.controller.search.mapper;

import org.dromara.easyes.core.kernel.BaseEsMapper;
import com.ruoyi.web.controller.search.model.EsTextDocument;

/**
 * 全文索引检索实体
 * 
 * @author ruoyi
 */
public interface EsTextDocumentMapper extends BaseEsMapper<EsTextDocument>
{
}
