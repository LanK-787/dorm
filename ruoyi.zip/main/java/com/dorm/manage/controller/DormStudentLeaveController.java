package com.dorm.manage.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.dorm.common.annotation.Log;
import com.dorm.common.core.controller.BaseController;
import com.dorm.common.core.domain.AjaxResult;
import com.dorm.common.enums.BusinessType;
import com.dorm.manage.domain.DormStudentLeave;
import com.dorm.manage.service.IDormStudentLeaveService;
import com.dorm.common.utils.poi.ExcelUtil;
import com.dorm.common.core.page.TableDataInfo;

/**
 * 学生离校登记Controller
 * 
 * @author 王新瑜
 * @date 2025-06-19
 */
@RestController
@RequestMapping("/dorm/leave")
public class DormStudentLeaveController extends BaseController
{
    @Autowired
    private IDormStudentLeaveService dormStudentLeaveService;

    /**
     * 查询学生离校登记列表
     */
    @PreAuthorize("@ss.hasPermi('dorm:leave:list')")
    @GetMapping("/list")
    public TableDataInfo list(DormStudentLeave dormStudentLeave)
    {
        startPage();
        List<DormStudentLeave> list = dormStudentLeaveService.selectDormStudentLeaveList(dormStudentLeave);
        return getDataTable(list);
    }

    /**
     * 导出学生离校登记列表
     */
    @PreAuthorize("@ss.hasPermi('dorm:leave:export')")
    @Log(title = "学生离校登记", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, DormStudentLeave dormStudentLeave)
    {
        List<DormStudentLeave> list = dormStudentLeaveService.selectDormStudentLeaveList(dormStudentLeave);
        ExcelUtil<DormStudentLeave> util = new ExcelUtil<DormStudentLeave>(DormStudentLeave.class);
        util.exportExcel(response, list, "学生离校登记数据");
    }

    /**
     * 获取学生离校登记详细信息
     */
    @PreAuthorize("@ss.hasPermi('dorm:leave:query')")
    @GetMapping(value = "/{leaveId}")
    public AjaxResult getInfo(@PathVariable("leaveId") Long leaveId)
    {
        return success(dormStudentLeaveService.selectDormStudentLeaveByLeaveId(leaveId));
    }

    /**
     * 新增学生离校登记
     */
    @PreAuthorize("@ss.hasPermi('dorm:leave:add')")
    @Log(title = "学生离校登记", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody DormStudentLeave dormStudentLeave)
    {
        return toAjax(dormStudentLeaveService.insertDormStudentLeave(dormStudentLeave));
    }

    /**
     * 修改学生离校登记
     */
    @PreAuthorize("@ss.hasPermi('dorm:leave:edit')")
    @Log(title = "学生离校登记", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody DormStudentLeave dormStudentLeave)
    {
        return toAjax(dormStudentLeaveService.updateDormStudentLeave(dormStudentLeave));
    }

    /**
     * 删除学生离校登记
     */
    @PreAuthorize("@ss.hasPermi('dorm:leave:remove')")
    @Log(title = "学生离校登记", businessType = BusinessType.DELETE)
	@DeleteMapping("/{leaveIds}")
    public AjaxResult remove(@PathVariable Long[] leaveIds)
    {
        return toAjax(dormStudentLeaveService.deleteDormStudentLeaveByLeaveIds(leaveIds));
    }
}
